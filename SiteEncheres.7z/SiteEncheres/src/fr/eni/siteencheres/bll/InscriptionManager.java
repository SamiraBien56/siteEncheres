package fr.eni.siteencheres.bll;

import java.sql.SQLException;

import fr.eni.siteencheres.bo.Utilisateur;
import fr.eni.siteencheres.dal.DAOFactory;
import fr.eni.siteencheres.dal.UtilisateurDAO;


public class InscriptionManager {
	private UtilisateurDAO utilisateurDAO;

	public InscriptionManager(UtilisateurDAO utilisateurDAO) {
		super();
		this.utilisateurDAO = DAOFactory.getUtilisateurDAO();
	}
	
	public InscriptionManager() {
		super();
		this.utilisateurDAO = DAOFactory.getUtilisateurDAO();
	}

	public UtilisateurDAO getUtilisateurDAO() {
		return utilisateurDAO;
	}

	public void setUtilisateurDAO(UtilisateurDAO utilisateurDAO) {
		this.utilisateurDAO = utilisateurDAO;
	}
	
	public void ajouterUtilisateur(String pseudo, String nom, String prenom, String email, String telephone, String rue,
			String code_postal, String ville, String mot_de_passe, int credit, boolean administrateur) throws SQLException {
		Utilisateur utilisateur = new Utilisateur();
		utilisateur.setPseudo(pseudo);
		utilisateur.setNom(nom);
		utilisateur.setPrenom(prenom);
		utilisateur.setEmail(email);
		utilisateur.setTelephone(telephone);
		utilisateur.setRue(rue);
		utilisateur.setCode_postal(code_postal);
		utilisateur.setVille(ville);
		utilisateur.setMot_de_passe(mot_de_passe);
		utilisateur.setCredit(credit);
		utilisateur.setAdministrateur(administrateur);
		
		utilisateurDAO.insert(utilisateur);
		
	}
	
	public boolean verifDoublePassword(String mdp, String vMdp) {
		if(mdp.equals(vMdp)) {
			return true;
		}
		return false;
	}
}
