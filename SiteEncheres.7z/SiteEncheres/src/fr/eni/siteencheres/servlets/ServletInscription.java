package fr.eni.siteencheres.servlets;

import java.io.IOException;
import java.sql.SQLException;

import fr.eni.siteencheres.bll.InscriptionManager;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletInscription
 */

@WebServlet("/inscription")
public class ServletInscription extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/inscription.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		InscriptionManager inscriptionManager = new InscriptionManager();
		
		request.setCharacterEncoding("UTF-8");
		boolean vDoubleMp = false;
		String erreur1 = null;
		
		
		
		String pseudo = request.getParameter("pseudo");
		String nom = request.getParameter("nom");
		String prenom = request.getParameter("prenom");
		String email = request.getParameter("email");
		String telephone = request.getParameter("telephone");
		String rue = request.getParameter("rue");
		String code_postal = request.getParameter("code_postal");
		String ville = request.getParameter("ville");
		String mot_de_passe = request.getParameter("motDePasse");
		String verifMotDePasse = request.getParameter("verifMotDePasse");
		int credit = 0;
		boolean administrateur=false;
		
		if(inscriptionManager.verifDoublePassword(mot_de_passe , verifMotDePasse)== true ) {
			vDoubleMp=true;}
			else {
				erreur1="Veuillez entrer deux mot de passe identiques";
			}
		if(vDoubleMp==true) {
			try {
				try {
					inscriptionManager.ajouterUtilisateur(pseudo,nom, prenom,email,telephone, rue,code_postal,ville, mot_de_passe,credit,administrateur);
				} catch ( SQLException e) {
				
					e.printStackTrace();
				}
			RequestDispatcher rd = request.getRequestDispatcher("/encheres.jsp");
			rd.forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
			}
		}
		else {
			try {
				request.getSession().setAttribute("pseudo", pseudo);
				request.getSession().setAttribute("nom", nom);
				request.getSession().setAttribute("prenom", prenom);
				request.getSession().setAttribute("email", email);
				request.getSession().setAttribute("telephone", telephone);
				request.getSession().setAttribute("rue", rue);
				request.getSession().setAttribute("code_postal", code_postal);
				request.getSession().setAttribute("ville", ville);
				
				RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/inscription.jsp");
				request.setAttribute("erreur", erreur1);
				
				rd.forward(request, response);
				
			} catch (ServletException e) {
				e.printStackTrace();
				throw new ServletException("Erreur servlet");
			}}}}


		
